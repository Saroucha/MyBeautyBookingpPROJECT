<?php

define('hostname', 'localhost');
define('user', 'nek');
define('password', 'aoudjit');
define('db_name', 'mybeautybooking');


?>
